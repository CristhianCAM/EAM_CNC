package com.dockerAplication.dockerAplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerAplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
