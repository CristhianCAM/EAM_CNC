package com.dockerAplication.dockerAplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DockerAplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(DockerAplicationApplication.class, args);
	}

}
